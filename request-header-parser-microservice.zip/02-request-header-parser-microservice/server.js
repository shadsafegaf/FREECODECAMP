// server.js
// where your node app starts

require('dotenv').config();
var express = require('express');
var app = express();

// enable CORS so that your API is remotely testable by FCC
var cors = require('cors');
app.use(cors({ optionsSuccessStatus: 200 }));

// serve static files
app.use(express.static('public'));

// basic routing
app.get("/", function (req, res) {
    res.sendFile(__dirname + '/views/index.html');
});

// example endpoint
app.get("/api/hello", function (req, res) {
    res.json({ greeting: 'hello API' });
});

// main API endpoint for request header parsing
app.get("/api/whoami", (req, res) => {
    res.json({
        ipaddress: req.ip || req.connection.remoteAddress,
        language: req.get('accept-language'),
        software: req.get('user-agent')
    });
});

// listen for requests
var listener = app.listen(process.env.PORT || 3000, function () {
    console.log('Your app is listening on port ' + listener.address().port);
});
