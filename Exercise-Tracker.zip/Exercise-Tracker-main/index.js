const express = require('express');
const app = express();

const cors = require('cors');
const bodyParser = require('body-parser');
const uuid = require('uuid');
const { check, validationResult } = require('express-validator');
const fs = require('fs');

require('dotenv').config();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/views/index.html');
});

function dataManagement(action, input) {
  const filePath = './public/data.json';
  if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, '[]');

  let Alldata = [];
  try {
    const file = fs.readFileSync(filePath, 'utf8');
    Alldata = file ? JSON.parse(file) : [];
  } catch (err) {
    console.error("Error reading data.json", err);
    Alldata = [];
  }

  if (action === 'save data' && input != null) {
    const index = Alldata.findIndex(d => d._id === input._id);
    if (index === -1) {
      Alldata.push(input);
    } else {
      Alldata[index] = input;
    }
    fs.writeFileSync(filePath, JSON.stringify(Alldata, null, 2));
  }

  if (action === 'load data') return Alldata;
}

// Generate unique id (no username restriction)
function gen_id() {
  const Alldata = dataManagement("load data");
  let id;
  do {
    id = uuid.v4().replace(/-/g, "").slice(0, 24);
  } while (Alldata.some(d => d._id === id));
  return id;
}

// Create new user
app.post('/api/users',
  [check('username', 'username is required').isLength({ min: 1 })],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.json({ errors: errors.array() });

    const username = req.body.username;
    const id = gen_id();

    const user = { username, _id: id, log: [] };
    dataManagement('save data', user);
    res.json({ username, _id: id });
  }
);

// Get all users
app.get('/api/users', (req, res) => {
  const Alldata = dataManagement("load data");
  const users = Alldata.map(d => ({ username: d.username, _id: d._id }));
  res.json(users);
});

// Add exercise
app.post('/api/users/:_id/exercises',
  [
    check('description', 'description is required').isLength({ min: 1 }),
    check('duration', 'duration must be a number').isInt({ min: 1 })
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.json({ errors: errors.array() });

    const { description, duration, date } = req.body;
    const id = req.params._id;
    const Alldata = dataManagement('load data');
    const found_user = Alldata.find(user => user._id === id);
    if (!found_user) return res.json({ error: 'Invalid user id' });

    const logDate = date && !isNaN(Date.parse(date)) ? new Date(date) : new Date();
    const log_entry = {
      description: String(description),
      duration: Number(duration),
      date: logDate.toDateString()
    };

    found_user.log = Array.isArray(found_user.log) ? found_user.log : [];
    found_user.log.push(log_entry);
    dataManagement('save data', found_user);

    // Return full user object with exercise fields added
    res.json({
      _id: found_user._id,
      username: found_user.username,
      description: log_entry.description,
      duration: log_entry.duration,
      date: log_entry.date
    });
  }
);

// Get logs
app.get('/api/users/:_id/logs', (req, res) => {
  const { from, to, limit } = req.query;
  const id = req.params._id;
  const Alldata = dataManagement('load data');
  const found_user = Alldata.find(user => user._id === id);
  if (!found_user) return res.json({ error: 'Invalid user id' });

  let logs = Array.isArray(found_user.log) ? [...found_user.log] : [];

  if (from && !isNaN(Date.parse(from))) {
    const fromDate = new Date(from);
    logs = logs.filter(e => new Date(e.date) >= fromDate);
  }

  if (to && !isNaN(Date.parse(to))) {
    const toDate = new Date(to);
    logs = logs.filter(e => new Date(e.date) <= toDate);
  }

  if (limit && !isNaN(limit)) {
    logs = logs.slice(0, parseInt(limit));
  }

  res.json({
    _id: found_user._id,
    username: found_user.username,
    count: logs.length,
    log: logs.map(e => ({
      description: e.description,
      duration: e.duration,
      date: e.date
    }))
  });
});

const listener = app.listen(process.env.PORT || 3000, () => {
  console.log('Your app is listening on port ' + listener.address().port);
});
